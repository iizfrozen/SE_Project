<?php
	$user = 'root';
	$pass = '';
	$db = 'seproject';
	$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
	$idToDelete = (isset($_GET['idToDelete']) ? $_GET['idToDelete'] : null);
	
	$result2 = false; 
	if($idToDelete != NULL){
		$sql = "DELETE FROM notes WHERE id = ".$idToDelete;
		$result2 = $db->query($sql);
		if($result2 == false){
			echo $sql;
		}
		else{
			echo "0";
		}
	}
	else 
		echo "idToDelete is not defined"


?>