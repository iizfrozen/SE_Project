<?php 
	$user = 'root';
	$pass = '';
	$db = 'seproject';
	$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");


	$query = "SELECT * FROM notes"; //notes may have to be changed depending on database
	$result = $db->query($query);
	if($result->num_rows > 0){
			echo "<table border ='1'><tr><th>Message</th><th>User</th><th>Date</th> <th> ID</th></tr>"; // start a table tag in the HTML
			while($row = $result->fetch_assoc()){
				echo "<tr> <td>".$row["message"]."</td><td>".$row["user"]."</td><td>".$row["date"]."</td><td>".$row["id"]."</td></tr>";
			}
			echo "</table>";
		}
		else{
			echo "No notes to display";
	}


	$db->close();


?>