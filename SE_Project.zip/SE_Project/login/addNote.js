

function GetXmlHttpObject() {
    var xmlHttp = null;
    if (window.XMLHttpRequest) {
        // IE 7+, Safari, Opera, Firefox, etc.   
        xmlHttp = new XMLHttpRequest();
    }
    else {	// for IE 5 & 6 
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlHttp;
}
function displayNotes(){
	xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            document.getElementById("displaynotes").innerHTML = xmlHttp.responseText;
        }
        else {
            document.getElementById("displaynotes").innerHTML = xmlHttp.responseText;
        }
    }
    xmlHttp.open("GET", "displayNote.php", true);
    xmlHttp.send();
}
function deleteNote(){
	var idToDelete = document.getElementById("idToDelete").value; 
	xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            if (xmlHttp.responseText == "0") {
                document.getElementById("error").innerHTML = "Message was deleted successfully.";
				displayNotes(); 
            }
            else
                document.getElementById("error").innerHTML = "Error";
        }
        else {
            document.getElementById("error").innerHTML = xmlHttp.responseText;
        }
    }
    xmlHttp.open("GET", "deleteNote.php?idToDelete="+idToDelete, true);
    xmlHttp.send();
}


function addNote(){
	var message = document.getElementById("message").value; 
	var user =    document.getElementById("user").value; 
	
	var xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            if (xmlHttp.responseText == "0") {
                document.getElementById("error").innerHTML = "Message was added successfully.";
				displayNotes(); 
            }
            else
                document.getElementById("error").innerHTML = "Error";
        }
	}
	xmlHttp.open("GET", "addNote.php?message=" +message + "&user=" + user, true);
    xmlHttp.send();
	
	
}