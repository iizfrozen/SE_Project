
        var xmlHttp;
        function submitButton() {
            var name = document.getElementById("username").value;
            var pass = document.getElementById("password").value;
            xmlHttp = GetXmlHttpObject();
            if(xmlHttp==null)
            {
                document.getElementById("display").innerHTML = "Error";
                return;
            }
            xmlHttp.onreadystatechange = function () {
                var response = xmlHttp.responseText;
                if (response == pass && response != "") {
                    if (name) {
                        document.getElementById("display").innerHTML = "";
                        document.getElementById("password").value = "";
                        document.getElementById("form1").submit();
                    }
					else{
						document.getElementById("display").innerHTML = "Invalid login info";
					}
                }
            }
            xmlHttp.open("GET", "login.php?uname=" + name, true);
            xmlHttp.send();
        }
        function GetXmlHttpObject() {
            xmlHttp = null;
            if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest();
            }
            else {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP")
            }
            return xmlHttp;
        }