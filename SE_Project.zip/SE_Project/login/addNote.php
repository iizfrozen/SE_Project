<?php
	$user = 'root';
	$pass = '';
	$db = 'seproject';
	$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
	
	$message = (isset($_GET['message']) ? $_GET['message'] : null);
	$user    = (isset($_GET['user']) ? $_GET['user'] : null);
	$result2 = false; 
	if($message != NULL){
		$sql = "INSERT INTO notes (message, user, date) VALUES('$message','$user', DEFAULT)";
		$result2 = $db->query($sql);
		if($result2 == false){
			echo $sql;
		}
		else{
			echo "0";
		}
	}




?>