<?php
	$user = 'root';
	$pass = '';
	$db = 'seproject';
	$link = mysqli_connect("localhost", $user,$pass,$db);
	$Cid = (isset($_GET['id']) ? $_GET['id'] : null);
	/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
 
	/* choose your own table name */

	$sql = "CREATE TABLE  `seproject`.`$Cid` (`someid` INT(6) NOT NULL AUTO_INCREMENT,`fname` VARCHAR(18) NOT NULL,`lname` VARCHAR(18) NOT NULL, `IDnumber` VARCHAR(10) NOT NULL, PRIMARY KEY (`someid`)) ENGINE=InnoDB DEFAULT CHARSET=latin1";
	/* Create table */
	if (mysqli_query($link, $sql) === TRUE) {
		printf("Table $Cid successfully created.\n");
	}
	else {
		printf("Could not create Table $tablename.\n");
	}	
 
	mysqli_close($link);
?>

>