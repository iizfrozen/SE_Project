<?php
	$user = 'root';
	$pass = '';
	$db='seproject';
	$link = mysqli_connect("localhost", $user,$pass,$db);
 
	/* check connection */
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	$ID = (isset($_GET['ID']) ? $_GET['ID'] : null);
	$fname = (isset($_GET['fname']) ? $_GET['fname'] : null);
	$lname = (isset($_GET['lname']) ? $_GET['lname'] : null);
	$IDnumber = (isset($_GET['IDnumber']) ? $_GET['IDnumber'] : null);

	$sql = "INSERT INTO `" .$ID. "` (fname,lname,IDnumber) VALUES('$fname','$lname','$IDnumber')";
	//$sql = "INSERT INTO clinictable (Cname,Cdate,Ctime,Ccap,Cinstr) VALUES('test','test','test','test','test')";	
		
	if (mysqli_query($link, $sql) === TRUE) {
		printf("Successfully added student.\n");
	}
	else{
		printf("Could not add student.\n");
		echo $sql;
	}
	
	mysqli_close($link);
?>