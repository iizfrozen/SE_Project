var xmlHttp;

function GetXmlHttpObject() {
    xmlHttp = null;
    if (window.XMLHttpRequest) {
        // IE 7+, Safari, Opera, Firefox, etc.   
        xmlHttp = new XMLHttpRequest();
    }
    else {	// for IE 5 & 6 
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlHttp;
}
function displayClinic() {
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            document.getElementById("displayclinics").innerHTML = xmlHttp.responseText;
        }
        else {
            document.getElementById("displayclinics").innerHTML = xmlHttp.responseText;
        }
    }
    xmlHttp.open("GET", "displayClinic.php", true);
    xmlHttp.send();
}
var xmlHttp;

function GetXmlHttpObject() {
    xmlHttp = null;
    if (window.XMLHttpRequest) {
        // IE 7+, Safari, Opera, Firefox, etc.   
        xmlHttp = new XMLHttpRequest();
    }
    else {	// for IE 5 & 6 
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlHttp;
}
function addClinic() {
    var Cname = document.getElementById("Clinicname").value;
    var Cdate = document.getElementById("date").value;
    var Ctime = document.getElementById("time").value;
    var Ccap = document.getElementById("capacity").value;
    var Cinstr = document.getElementById("instructor").value;
	var id = document.getElementById("Clinicid").value;
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            if (xmlHttp.responseText == "0") {
                document.getElementById("error").innerHTML = Cname + " was added successfully.";
            }
            else if (xmlHttp.responseText == "1")
                document.getElementById("error").innerHTML = Cname + " already exists";
            else
                document.getElementById("error").innerHTML = "Error in adding clinic";
        }
    }
    xmlHttp.open("GET", "addClinic.php?Cname=" + Cname + "&Cdate=" + Cdate + "&Ctime=" + Ctime + "&Ccap=" + Ccap + "&Cinstr=" + Cinstr + "&Cid=" + id , true);
    xmlHttp.send();
}

function addNewTable(){
	var id = document.getElementById("Clinicid").value;
	xmlHttp = GetXmlHttpObject();
	if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
	xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            if (xmlHttp.responseText == "0") {
                document.getElementById("error").innerHTML = " Table was added successfully.";
            }
            else if (xmlHttp.responseText == "1")
                document.getElementById("error").innerHTML = "Table already exists";
            else
                document.getElementById("error").innerHTML = "Error in adding Table";
        }
    }
	xmlHttp.open("GET", "newTable.php?id="+id, true);
	xmlHttp.send();
}

function deleteclinic(){
	var did = document.getElementById("did").value;
	xmlHttp=GetXmlHttpObject();
	if(xmlHttp==null){
		document.getElementById("error").innerHTML="Browser does not support HTTP Request";
		return;
	}
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 && xmlHttp.status == 200){
			if(xmlHttp.responseText == ""){
				document.getElementById("error").innerHTML = did+" was deleted successfully.";
			}
			else{
				document.getElementById("error").innerHTMl = "Error";
			}
		}
		else{
			document.getElementById("error").innerHTML = xmlHttp.responseText;
		}
	}
	xmlHttp.open("GET","deleteClinic.php?did="+did,true);
	xmlHttp.send();
}

function addStudent() {
	var ID = document.getElementById("IDs").value;
	var fname = document.getElementById("firstname").value;
	var lname = document.getElementById("lastname").value;
	var IDnumber = document.getElementById("IDnumber").value;
	xmlHttp=GetXmlHttpObject();
	if(xmlHttp==null){
		document.getElementById("error").innerHTML="Browser does not support HTTP Request";
		return;
	}
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 && xmlHttp.status == 200){
			if(xmlHttp.responseText == "0"){
				document.getElementById("error").innerHTML = fname+" was added successfully.";
			}
			else if(xmlHttp.responseText == "1")
				document.getElementById("error").innerHTML = fname+" already exists";
			else
				document.getElementById("error").innerHTML = "Error in adding user";
		}
		else{
			document.getElementById("error").innerHTML = xmlHttp.responseText;
		}
	}
	xmlHttp.open("GET","addStudent.php?ID="+ID+ "&fname="+fname+"&lname="+lname+"&IDnumber="+IDnumber,true);
	xmlHttp.send();
}

function displayStudents() {
	var ID = document.getElementById("ID").value;
    xmlHttp = GetXmlHttpObject();
    if (xmlHttp == null) {
        document.getElementById("error").innerHTML = "Browser does not support HTTP Request";
        return;
    }
    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
            document.getElementById("displaystudent").innerHTML = xmlHttp.responseText;
        }
        else {
            document.getElementById("displaystudent").innerHTML = xmlHttp.responseText;
        }
    }
    xmlHttp.open("GET", "displayStudents.php?ID="+ID, true);
    xmlHttp.send();
}