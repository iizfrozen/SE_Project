<?php
	$user = 'root';
	$pass = '';
	$db = 'seproject';
	$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
	$ID = (isset($_GET['ID']) ? $_GET['ID'] : null);
	$query = "SELECT * FROM `" .$ID. "`"; //clinictable may have to be changed depending on database
	$result = $db->query($query);
	if($result != FAlSE)
		if($result->num_rows > 0){
				echo "<table border ='1'><tr><th>First NAme</th><th>Last Name</th><th>ID Number</th></tr>"; // start a table tag in the HTML
				while($row = $result->fetch_assoc()){
					echo "<tr> <td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["IDnumber"]."</td></tr>";
				}
				echo "</table>";
			}
			else{
				echo "0 results";
		}
	else
		echo "0 results";
	$db->close();
?>