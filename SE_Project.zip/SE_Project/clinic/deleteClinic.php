<?php
	$user = 'root';
	$pass = '';
	$db='seproject';
	$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
	$did = (isset($_GET['did']) ? $_GET['did'] : null);
	$sql = "DELETE FROM clinictable WHERE Id='".$did."'";
	$result2 = $db->query("DROP TABLE $did;");
	$result = $db->query($sql);
	$db->close();
?>